#!/usr/bin/env bash
set -euo pipefail

# ── Polymarket Arbitrage Bot - One-Command Deploy ──────────────────────────────
# Usage:
#   ./deploy.sh --cloud gcp --project my-gcp-project
#   ./deploy.sh --cloud aws --region me-south-1
#   ./deploy.sh --cloud digitalocean
#   ./deploy.sh --cloud local  (Docker only, no cloud infra)

CLOUD=""
GCP_PROJECT=""
AWS_REGION="me-south-1"
DO_TOKEN=""
REGION=""
SKIP_TERRAFORM=false
SKIP_ANSIBLE=false
SKIP_SECRETS=false

# ── Colors ─────────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log()     { echo -e "${GREEN}[+]${NC} $1"; }
warn()    { echo -e "${YELLOW}[!]${NC} $1"; }
error()   { echo -e "${RED}[x]${NC} $1"; exit 1; }
section() { echo -e "\n${BLUE}══════════════════════════════════════${NC}"; echo -e "${BLUE}  $1${NC}"; echo -e "${BLUE}══════════════════════════════════════${NC}\n"; }

# ── Parse Arguments ────────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case $1 in
    --cloud)           CLOUD="$2";           shift 2 ;;
    --project)         GCP_PROJECT="$2";     shift 2 ;;
    --region)          REGION="$2";          shift 2 ;;
    --do-token)        DO_TOKEN="$2";        shift 2 ;;
    --skip-terraform)  SKIP_TERRAFORM=true;  shift ;;
    --skip-ansible)    SKIP_ANSIBLE=true;    shift ;;
    --skip-secrets)    SKIP_SECRETS=true;    shift ;;
    *) error "Unknown argument: $1" ;;
  esac
done

# ── Validate ───────────────────────────────────────────────────────────────────
[[ -z "$CLOUD" ]] && error "Must specify --cloud (gcp|aws|digitalocean|local)"

section "Polymarket Arbitrage Bot Deploy"
log "Cloud: $CLOUD"
log "Started: $(date)"

# ── Check Prerequisites ────────────────────────────────────────────────────────
section "Checking Prerequisites"

check_cmd() {
  command -v "$1" &>/dev/null && log "$1 found" || error "$1 not found. Please install it first."
}

check_cmd terraform
check_cmd ansible-playbook
check_cmd docker

case $CLOUD in
  gcp)
    check_cmd gcloud
    [[ -z "$GCP_PROJECT" ]] && error "GCP requires --project"
    ;;
  aws)
    check_cmd aws
    [[ -n "$REGION" ]] && AWS_REGION="$REGION"
    ;;
  digitalocean)
    check_cmd doctl
    [[ -z "$DO_TOKEN" ]] && error "DigitalOcean requires --do-token"
    ;;
  local)
    log "Local mode - skipping cloud infra"
    SKIP_TERRAFORM=true
    ;;
esac

# ── Check Secrets File ─────────────────────────────────────────────────────────
section "Checking Secrets"

if [[ ! -f ".env" ]]; then
  warn ".env file not found"
  if [[ -f "secrets.example" ]]; then
    cp secrets.example .env
    warn "Created .env from secrets.example"
    warn "Please fill in your secrets in .env then re-run this script"
    echo ""
    echo "Required secrets:"
    grep -E "^[A-Z_]+=your_" .env | cut -d= -f1 | while read key; do
      echo "  - $key"
    done
    exit 1
  fi
else
  log ".env file found"
  # Check required secrets are filled
  MISSING=0
  while IFS= read -r line; do
    if [[ "$line" =~ ^[A-Z_]+=your_ ]]; then
      key=$(echo "$line" | cut -d= -f1)
      warn "Not set: $key"
      MISSING=$((MISSING + 1))
    fi
  done < .env
  [[ $MISSING -gt 0 ]] && error "$MISSING secrets not configured. Please fill in .env"
  log "All secrets configured"
fi

# ── Generate SSH Key ───────────────────────────────────────────────────────────
section "SSH Key"

if [[ ! -f ~/.ssh/polymarket_bot_key ]]; then
  log "Generating SSH key pair..."
  ssh-keygen -t ed25519 -C "polymarket-bot-deploy" -f ~/.ssh/polymarket_bot_key -N ""
  log "SSH key generated at ~/.ssh/polymarket_bot_key"
else
  log "SSH key already exists"
fi

SSH_PUBLIC_KEY=$(cat ~/.ssh/polymarket_bot_key.pub)

# ── Terraform ──────────────────────────────────────────────────────────────────
VM_IP=""

if [[ "$SKIP_TERRAFORM" == "false" ]]; then
  section "Provisioning Infrastructure (Terraform)"

  TF_DIR="terraform/$CLOUD"
  [[ ! -d "$TF_DIR" ]] && error "Terraform directory not found: $TF_DIR"

  cd "$TF_DIR"
  terraform init

  case $CLOUD in
    gcp)
      terraform apply -auto-approve \
        -var="project_id=$GCP_PROJECT" \
        ${REGION:+-var="region=$REGION"}
      VM_NAME=$(terraform output -raw vm_name)
      VM_ZONE=$(terraform output -raw vm_zone)
      log "VM created: $VM_NAME in $VM_ZONE"
      ;;
    aws)
      terraform apply -auto-approve \
        -var="region=$AWS_REGION" \
        -var="ssh_public_key=$SSH_PUBLIC_KEY"
      INSTANCE_ID=$(terraform output -raw instance_id)
      log "EC2 instance created: $INSTANCE_ID"
      ;;
    digitalocean)
      terraform apply -auto-approve \
        -var="do_token=$DO_TOKEN" \
        -var="ssh_public_key=$SSH_PUBLIC_KEY" \
        ${REGION:+-var="region=$REGION"}
      VM_IP=$(terraform output -raw droplet_ip)
      log "Droplet created: $VM_IP"
      ;;
  esac

  terraform output next_steps || true
  cd - > /dev/null
fi

# ── Upload Secrets to Cloud ────────────────────────────────────────────────────
if [[ "$SKIP_SECRETS" == "false" ]]; then
  section "Uploading Secrets"

  source .env

  case $CLOUD in
    gcp)
      log "Uploading secrets to GCP Secret Manager..."
      upload_secret() {
        echo -n "$2" | gcloud secrets versions add "$1" \
          --project="$GCP_PROJECT" --data-file=- 2>/dev/null || \
        echo -n "$2" | gcloud secrets create "$1" \
          --project="$GCP_PROJECT" --data-file=- --replication-policy=automatic
        log "Uploaded: $1"
      }
      upload_secret "polymarket-api-key"        "$POLYMARKET_API_KEY"
      upload_secret "polymarket-api-secret"     "$POLYMARKET_API_SECRET"
      upload_secret "polymarket-api-passphrase" "$POLYMARKET_API_PASSPHRASE"
      upload_secret "polymarket-private-key"    "$POLYMARKET_PRIVATE_KEY"
      upload_secret "telegram-bot-token"        "$TELEGRAM_BOT_TOKEN"
      upload_secret "github-pat"                "$GITHUB_PAT"
      ;;
    aws)
      log "Uploading secrets to AWS Secrets Manager..."
      upload_secret() {
        aws secretsmanager put-secret-value \
          --secret-id "$1" \
          --secret-string "$2" \
          --region "$AWS_REGION" 2>/dev/null || \
        aws secretsmanager create-secret \
          --name "$1" \
          --secret-string "$2" \
          --region "$AWS_REGION"
        log "Uploaded: $1"
      }
      upload_secret "polymarket-api-key"        "$POLYMARKET_API_KEY"
      upload_secret "polymarket-api-secret"     "$POLYMARKET_API_SECRET"
      upload_secret "polymarket-api-passphrase" "$POLYMARKET_API_PASSPHRASE"
      upload_secret "polymarket-private-key"    "$POLYMARKET_PRIVATE_KEY"
      upload_secret "telegram-bot-token"        "$TELEGRAM_BOT_TOKEN"
      ;;
    digitalocean|local)
      log "Secrets stored in .env file on server (no managed secret service)"
      ;;
  esac
fi

# ── Ansible ────────────────────────────────────────────────────────────────────
if [[ "$SKIP_ANSIBLE" == "false" ]]; then
  section "Configuring VM (Ansible)"

  # Build inventory based on cloud
  case $CLOUD in
    gcp)
      cat > /tmp/inventory.ini << EOF
[all]
polymarket-bot ansible_host=poly-bot ansible_connection=community.google.gcp_compute ansible_user=sa_${GCP_PROJECT}
EOF
      ANSIBLE_EXTRA="--extra-vars gcp_project=$GCP_PROJECT"
      ;;
    aws)
      cat > /tmp/inventory.ini << EOF
[all]
polymarket-bot ansible_host=$INSTANCE_ID ansible_connection=aws_ssm ansible_aws_ssm_region=$AWS_REGION
EOF
      ANSIBLE_EXTRA=""
      ;;
    digitalocean|local)
      cat > /tmp/inventory.ini << EOF
[all]
polymarket-bot ansible_host=$VM_IP ansible_user=root ansible_ssh_private_key_file=~/.ssh/polymarket_bot_key
EOF
      ANSIBLE_EXTRA=""
      ;;
  esac

  log "Waiting 30s for VM to be ready..."
  sleep 30

  log "Running security hardening..."
  ansible-playbook -i /tmp/inventory.ini ansible/hardening.yml $ANSIBLE_EXTRA

  log "Deploying bot..."
  ansible-playbook -i /tmp/inventory.ini ansible/deploy.yml $ANSIBLE_EXTRA
fi

# ── Local Docker Mode ──────────────────────────────────────────────────────────
if [[ "$CLOUD" == "local" ]]; then
  section "Starting Local Docker Services"
  docker compose -f docker/docker-compose.yml up -d --build
  log "Services started"
  docker compose -f docker/docker-compose.yml ps
fi

# ── Done ───────────────────────────────────────────────────────────────────────
section "Deployment Complete"
log "Polymarket Arbitrage Bot deployed successfully"
log "Cloud: $CLOUD"
log "Finished: $(date)"
echo ""
echo "Next steps:"
echo "  1. Send /help to your Telegram bot to verify it's responding"
echo "  2. Send /opportunities to run your first market scan"
echo "  3. Send /balance to check your USDC balance"
echo ""
warn "Never commit .env to git - it contains your private keys"
