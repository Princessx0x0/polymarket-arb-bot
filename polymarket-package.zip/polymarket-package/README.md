# Polymarket Arbitrage Bot

Fully automated arbitrage trading bot for Polymarket. Detects and executes guaranteed-profit opportunities across 5 strategy types. Deploys to any cloud in one command.

## Quick Start

```bash
git clone https://github.com/Princessx0x0/polymarket-arb-bot
cd polymarket-arb-bot
cp secrets.example .env
# Fill in your secrets in .env
./deploy.sh --cloud gcp --project your-gcp-project
```

## Supported Clouds

| Cloud | Command | Monthly Cost |
|---|---|---|
| GCP (recommended) | `./deploy.sh --cloud gcp --project YOUR_PROJECT` | ~£12 |
| AWS | `./deploy.sh --cloud aws --region me-south-1` | ~£8 |
| DigitalOcean | `./deploy.sh --cloud digitalocean --do-token YOUR_TOKEN` | ~£4 |
| Local (Docker) | `./deploy.sh --cloud local` | Free |

## Required Secrets

Fill these in `.env` before deploying:

| Secret | Where to Find |
|---|---|
| `POLYMARKET_API_KEY` | Polymarket Settings → API |
| `POLYMARKET_API_SECRET` | Polymarket Settings → API |
| `POLYMARKET_API_PASSPHRASE` | Polymarket Settings → API |
| `POLYMARKET_PRIVATE_KEY` | Your Ethereum wallet private key |
| `POLYMARKET_FUNDER_ADDRESS` | Polymarket Settings → Proxy wallet address |
| `TELEGRAM_BOT_TOKEN` | @BotFather on Telegram |
| `TELEGRAM_CHAT_ID` | Your Telegram user ID |

## The 5 Arbitrage Strategies

### Strategy 1 — Basic Arb
Buy YES and NO on the same market. Total cost < $1 = guaranteed profit.
```
/execute1 slug budget
```

### Strategy 2 — Mutually Exclusive
Two markets where one MUST be true. Buy YES on both for < $1.
```
/execute2 slug-a slug-b budget
```

### Strategy 3 — Contradiction Arb
Two markets that contradict. Buy YES on one, NO on the other.
```
/execute3 slug-a slug-b budget
```

### Strategy 4 — One-of-Many
Multiple events where at least one must NOT happen. Buy NO on all.
```
/execute4 slug-a slug-b slug-c budget
```

### Strategy 5 — Must-Happen NegRisk (primary strategy)
NegRisk market where YES sum > $1. Buy NO on every condition.
```
/execute5 slug budget
```

## Telegram Commands

| Command | Description |
|---|---|
| `/balance` | Check USDC balance |
| `/opportunities` | Scan all markets for arb |
| `/positions` | View open positions |
| `/status` | Bot health check |
| `/execute slug budget` | Auto-detect and execute |

## Architecture

```
Telegram (phone)
    ↓ commands
VM (Doha/any cloud)
    ├── polymarket-scanner  (24/7, scans 2500+ markets every 5 min)
    └── polymarket-telegram (command & control)
            ↓ orders
    Polymarket CLOB API
            ↓ settlement
    Polygon blockchain
            ↓ logging
    BigQuery (159K+ opportunities)
```

## Security

- No external IP — Cloud NAT for outbound only
- IAP/SSM tunnel only for admin access
- All secrets in cloud secret manager
- Shielded VM (GCP) / Encrypted EBS (AWS)
- Minimal service account — 4 roles only

## Important Notes

- **Minimum budget**: $1 per condition. 20-condition market needs $20 minimum.
- **Geoblocking**: Polymarket blocks UK IPs. Use Doha (GCP me-central1), Bahrain (AWS me-south-1), or Singapore (DO sgp1).
- **Proxy wallet**: Your funder address is your Polymarket proxy wallet (Settings), NOT your MetaMask address.
- **Resolution**: Profits are locked until the market resolves. Champions League resolves May/Jun 2026.
