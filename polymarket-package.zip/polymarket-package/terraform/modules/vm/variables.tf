# modules/vm/variables.tf
# Cloud-agnostic VM configuration

variable "vm_name" {
  description = "Name of the virtual machine"
  type        = string
  default     = "polymarket-bot"
}

variable "machine_type" {
  description = "VM machine type (e.g. e2-small for GCP, t3.micro for AWS)"
  type        = string
  default     = "e2-small"
}

variable "region" {
  description = "Cloud region to deploy in"
  type        = string
}

variable "zone" {
  description = "Cloud zone/availability zone"
  type        = string
}

variable "ssh_public_key" {
  description = "SSH public key for VM access"
  type        = string
}

variable "tags" {
  description = "Resource tags/labels"
  type        = map(string)
  default     = {
    project     = "polymarket-bot"
    managed_by  = "terraform"
  }
}
