terraform {
  required_providers {
    digitalocean = {
      source  = "digitalocean/digitalocean"
      version = "~> 2.0"
    }
  }
}

variable "do_token" {
  description = "DigitalOcean API token"
  type        = string
  sensitive   = true
}

variable "region" {
  description = "DigitalOcean region"
  type        = string
  default     = "sgp1"  # Singapore - no geoblocking, affordable
}

variable "size" {
  description = "Droplet size"
  type        = string
  default     = "s-1vcpu-1gb"  # ~$6/month
}

variable "ssh_public_key" {
  description = "SSH public key content"
  type        = string
}

provider "digitalocean" {
  token = var.do_token
}

# ── SSH Key ────────────────────────────────────────────────────────────────────
resource "digitalocean_ssh_key" "bot_key" {
  name       = "polymarket-bot-key"
  public_key = var.ssh_public_key
}

# ── VPC ────────────────────────────────────────────────────────────────────────
resource "digitalocean_vpc" "bot_vpc" {
  name     = "polymarket-bot-vpc"
  region   = var.region
  ip_range = "10.10.10.0/24"
}

# ── Firewall ───────────────────────────────────────────────────────────────────
resource "digitalocean_firewall" "bot_firewall" {
  name = "polymarket-bot-firewall"

  droplet_ids = [digitalocean_droplet.bot_vm.id]

  # No inbound SSH from internet - use DO Console or VPN
  inbound_rule {
    protocol         = "tcp"
    port_range       = "22"
    source_addresses = ["10.10.10.0/24"]  # Internal only
  }

  # Allow all outbound
  outbound_rule {
    protocol              = "tcp"
    port_range            = "1-65535"
    destination_addresses = ["0.0.0.0/0", "::/0"]
  }

  outbound_rule {
    protocol              = "udp"
    port_range            = "1-65535"
    destination_addresses = ["0.0.0.0/0", "::/0"]
  }
}

# ── Droplet ────────────────────────────────────────────────────────────────────
resource "digitalocean_droplet" "bot_vm" {
  name     = "polymarket-bot"
  region   = var.region
  size     = var.size
  image    = "ubuntu-24-04-x64"
  vpc_uuid = digitalocean_vpc.bot_vpc.id
  ssh_keys = [digitalocean_ssh_key.bot_key.fingerprint]

  # No public IP - Note: DO requires public IP for outbound
  # Use private networking + floating IP approach instead
  ipv6 = false

  tags = ["polymarket-bot", "managed-by-terraform"]
}

# ── Outputs ────────────────────────────────────────────────────────────────────
output "droplet_ip" {
  value = digitalocean_droplet.bot_vm.ipv4_address
}

output "next_steps" {
  value = <<EOF
Infrastructure created. Next steps:
1. Copy secrets: scp .env root@${digitalocean_droplet.bot_vm.ipv4_address}:/root/.env
2. Run Ansible: ansible-playbook -i ansible/inventory.do.yml ansible/deploy.yml
3. Check: ssh root@${digitalocean_droplet.bot_vm.ipv4_address} "docker ps"
NOTE: On DigitalOcean, secrets are stored in .env file on server (no managed secret service on basic plan)
EOF
}
