terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.region
}

variable "region" {
  description = "AWS region"
  type        = string
  default     = "me-south-1"  # Bahrain - close to Doha, no geoblocking
}

variable "instance_type" {
  description = "EC2 instance type"
  type        = string
  default     = "t3.micro"
}

variable "ssh_public_key" {
  description = "SSH public key content"
  type        = string
}

# ── Key Pair ───────────────────────────────────────────────────────────────────
resource "aws_key_pair" "bot_key" {
  key_name   = "polymarket-bot-key"
  public_key = var.ssh_public_key
}

# ── VPC & Networking ───────────────────────────────────────────────────────────
resource "aws_vpc" "bot_vpc" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  tags = { Name = "polymarket-bot-vpc" }
}

resource "aws_subnet" "bot_subnet" {
  vpc_id            = aws_vpc.bot_vpc.id
  cidr_block        = "10.0.1.0/24"
  availability_zone = "${var.region}a"
  tags = { Name = "polymarket-bot-subnet" }
}

resource "aws_internet_gateway" "igw" {
  vpc_id = aws_vpc.bot_vpc.id
  tags = { Name = "polymarket-bot-igw" }
}

# NAT Gateway for outbound internet without public IP
resource "aws_eip" "nat_eip" {
  domain = "vpc"
}

resource "aws_nat_gateway" "nat" {
  allocation_id = aws_eip.nat_eip.id
  subnet_id     = aws_subnet.bot_subnet.id
  tags = { Name = "polymarket-bot-nat" }
}

resource "aws_route_table" "private_rt" {
  vpc_id = aws_vpc.bot_vpc.id
  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.nat.id
  }
  tags = { Name = "polymarket-bot-private-rt" }
}

resource "aws_route_table_association" "private_rta" {
  subnet_id      = aws_subnet.bot_subnet.id
  route_table_id = aws_route_table.private_rt.id
}

# ── Security Group ─────────────────────────────────────────────────────────────
resource "aws_security_group" "bot_sg" {
  name        = "polymarket-bot-sg"
  description = "Polymarket bot - SSH via SSM only"
  vpc_id      = aws_vpc.bot_vpc.id

  # No inbound SSH - use AWS SSM Session Manager (equivalent to GCP IAP)
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "polymarket-bot-sg" }
}

# ── IAM Role ───────────────────────────────────────────────────────────────────
resource "aws_iam_role" "bot_role" {
  name = "polymarket-bot-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "ec2.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy_attachment" "ssm_policy" {
  role       = aws_iam_role.bot_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

resource "aws_iam_role_policy" "secrets_policy" {
  name = "polymarket-secrets-policy"
  role = aws_iam_role.bot_role.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["secretsmanager:GetSecretValue"]
      Resource = "arn:aws:secretsmanager:${var.region}:*:secret:polymarket-*"
    }]
  })
}

resource "aws_iam_instance_profile" "bot_profile" {
  name = "polymarket-bot-profile"
  role = aws_iam_role.bot_role.name
}

# ── EC2 Instance ───────────────────────────────────────────────────────────────
data "aws_ami" "ubuntu" {
  most_recent = true
  owners      = ["099720109477"] # Canonical
  filter {
    name   = "name"
    values = ["ubuntu/images/hvm-ssd/ubuntu-noble-24.04-amd64-server-*"]
  }
}

resource "aws_instance" "bot_vm" {
  ami                    = data.aws_ami.ubuntu.id
  instance_type          = var.instance_type
  subnet_id              = aws_subnet.bot_subnet.id
  vpc_security_group_ids = [aws_security_group.bot_sg.id]
  iam_instance_profile   = aws_iam_instance_profile.bot_profile.name
  key_name               = aws_key_pair.bot_key.key_name

  # No public IP
  associate_public_ip_address = false

  root_block_device {
    volume_size = 20
    volume_type = "gp3"
    encrypted   = true
  }

  metadata_options {
    http_tokens = "required"  # IMDSv2 only - security hardening
  }

  tags = { Name = "polymarket-bot", managed_by = "terraform" }
}

# ── Secrets Manager ────────────────────────────────────────────────────────────
resource "aws_secretsmanager_secret" "secrets" {
  for_each = toset([
    "polymarket-api-key",
    "polymarket-api-secret",
    "polymarket-api-passphrase",
    "polymarket-private-key",
    "telegram-bot-token",
    "github-pat",
  ])
  name = each.value
}

output "instance_id" {
  value = aws_instance.bot_vm.id
}

output "next_steps" {
  value = <<EOF
Infrastructure created. Next steps:
1. Add secrets via AWS Console or CLI: aws secretsmanager put-secret-value --secret-id polymarket-api-key --secret-string "your-key"
2. Connect: aws ssm start-session --target ${aws_instance.bot_vm.id}
3. Run Ansible: ansible-playbook -i ansible/inventory.aws.yml ansible/deploy.yml
EOF
}
