terraform {
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
  # Uncomment to store state in GCS
  # backend "gcs" {
  #   bucket = "your-terraform-state-bucket"
  #   prefix = "polymarket-bot"
  # }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

# ── Variables ──────────────────────────────────────────────────────────────────
variable "project_id" {
  description = "GCP Project ID"
  type        = string
}

variable "region" {
  description = "GCP region"
  type        = string
  default     = "me-central1"  # Doha - no geoblocking
}

variable "zone" {
  description = "GCP zone"
  type        = string
  default     = "me-central1-a"
}

variable "machine_type" {
  description = "GCP machine type"
  type        = string
  default     = "e2-small"
}

# ── Enable APIs ────────────────────────────────────────────────────────────────
resource "google_project_service" "apis" {
  for_each = toset([
    "compute.googleapis.com",
    "secretmanager.googleapis.com",
    "bigquery.googleapis.com",
    "iap.googleapis.com",
    "cloudresourcemanager.googleapis.com",
    "logging.googleapis.com",
  ])
  service            = each.value
  disable_on_destroy = false
}

# ── Service Account ────────────────────────────────────────────────────────────
resource "google_service_account" "bot_sa" {
  account_id   = "poly-bot-sa"
  display_name = "Polymarket Bot Service Account"
}

resource "google_project_iam_member" "bot_sa_roles" {
  for_each = toset([
    "roles/bigquery.dataEditor",
    "roles/bigquery.jobUser",
    "roles/logging.logWriter",
    "roles/secretmanager.secretAccessor",
  ])
  project = var.project_id
  role    = each.value
  member  = "serviceAccount:${google_service_account.bot_sa.email}"
}

# ── Network ────────────────────────────────────────────────────────────────────
resource "google_compute_router" "router" {
  name    = "polymarket-router"
  region  = var.region
  network = "default"
}

resource "google_compute_router_nat" "nat" {
  name                               = "polymarket-nat"
  router                             = google_compute_router.router.name
  region                             = var.region
  nat_ip_allocate_option             = "AUTO_ONLY"
  source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"
}

# ── Firewall ───────────────────────────────────────────────────────────────────
resource "google_compute_firewall" "allow_iap" {
  name    = "allow-ssh-iap"
  network = "default"

  allow {
    protocol = "tcp"
    ports    = ["22"]
  }

  # Only Google IAP source IPs
  source_ranges = ["35.235.240.0/20"]
  target_tags   = ["polymarket-bot"]
}

resource "google_compute_firewall" "allow_internal" {
  name    = "allow-internal"
  network = "default"

  allow {
    protocol = "tcp"
    ports    = ["0-65535"]
  }
  allow {
    protocol = "udp"
    ports    = ["0-65535"]
  }
  allow {
    protocol = "icmp"
  }

  source_ranges = ["10.128.0.0/9"]
}

# ── VM Instance ────────────────────────────────────────────────────────────────
resource "google_compute_instance" "bot_vm" {
  name         = "poly-bot"
  machine_type = var.machine_type
  zone         = var.zone

  tags = ["polymarket-bot"]

  boot_disk {
    initialize_params {
      image = "ubuntu-os-cloud/ubuntu-2404-lts"
      size  = 20
      type  = "pd-standard"
    }
  }

  network_interface {
    network = "default"
    # No access_config = no external IP
  }

  service_account {
    email  = google_service_account.bot_sa.email
    scopes = ["cloud-platform"]
  }

  # Shielded VM
  shielded_instance_config {
    enable_secure_boot          = true
    enable_vtpm                 = true
    enable_integrity_monitoring = true
  }

  # OS Login
  metadata = {
    enable-oslogin = "TRUE"
  }

  labels = {
    project    = "polymarket-bot"
    managed_by = "terraform"
  }

  depends_on = [google_project_service.apis]
}

# ── BigQuery ───────────────────────────────────────────────────────────────────
resource "google_bigquery_dataset" "polymarket" {
  dataset_id  = "polymarket"
  location    = "US"
  description = "Polymarket arbitrage bot data"
}

resource "google_bigquery_table" "market_ticks" {
  dataset_id          = google_bigquery_dataset.polymarket.dataset_id
  table_id            = "market_ticks_v2"
  deletion_protection = false

  schema = jsonencode([
    { name = "ts",        type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "market_id", type = "STRING",    mode = "REQUIRED" },
    { name = "price",     type = "FLOAT",     mode = "REQUIRED" },
    { name = "raw",       type = "STRING",    mode = "NULLABLE" },
  ])
}

resource "google_bigquery_table" "paper_trades" {
  dataset_id          = google_bigquery_dataset.polymarket.dataset_id
  table_id            = "paper_trades"
  deletion_protection = false

  schema = jsonencode([
    { name = "ts",                type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "event_title",       type = "STRING",    mode = "NULLABLE" },
    { name = "event_slug",        type = "STRING",    mode = "NULLABLE" },
    { name = "direction",         type = "STRING",    mode = "NULLABLE" },
    { name = "yes_sum",           type = "FLOAT",     mode = "NULLABLE" },
    { name = "profit_per_dollar", type = "FLOAT",     mode = "NULLABLE" },
    { name = "num_conditions",    type = "INTEGER",   mode = "NULLABLE" },
    { name = "volume_24hr",       type = "FLOAT",     mode = "NULLABLE" },
  ])
}

# ── Secret Manager ─────────────────────────────────────────────────────────────
resource "google_secret_manager_secret" "secrets" {
  for_each  = toset([
    "polymarket-api-key",
    "polymarket-api-secret",
    "polymarket-api-passphrase",
    "polymarket-private-key",
    "telegram-bot-token",
    "github-pat",
  ])
  secret_id = each.value
  replication { auto {} }
}

# ── Outputs ────────────────────────────────────────────────────────────────────
output "vm_name" {
  value = google_compute_instance.bot_vm.name
}

output "vm_zone" {
  value = google_compute_instance.bot_vm.zone
}

output "service_account" {
  value = google_service_account.bot_sa.email
}

output "next_steps" {
  value = <<EOF
Infrastructure created. Next steps:
1. Add secrets: gcloud secrets versions add polymarket-api-key --data-file=-
2. Run Ansible: ansible-playbook -i ansible/inventory.gcp.yml ansible/deploy.yml
3. Check services: gcloud compute ssh poly-bot --tunnel-through-iap --command="sudo systemctl status polymarket-*"
EOF
}
